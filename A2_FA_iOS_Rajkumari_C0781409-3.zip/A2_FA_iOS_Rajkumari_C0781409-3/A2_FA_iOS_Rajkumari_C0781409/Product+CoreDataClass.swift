//
//  Product+CoreDataClass.swift
//  A2_FA_iOS_Rajkumari_C0781409
//
//  Created by Rajkumari on 31/01/21.
//  Copyright © 2021 RajKumari. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Product)
public class Product: NSManagedObject {

}
