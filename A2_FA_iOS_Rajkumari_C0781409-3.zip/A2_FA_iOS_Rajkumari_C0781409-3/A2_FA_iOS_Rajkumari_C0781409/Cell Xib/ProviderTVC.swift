//
//  ProviderTVC.swift
//  A2_FA_iOS_Rajkumari_C0781409
//
//  Created by RajKumari on 01/02/21.
//  Copyright © 2021 RajKumari. All rights reserved.
//

import UIKit

class ProviderTVC: UITableViewCell {
    @IBOutlet weak var lbTitle: UILabel!
    @IBOutlet weak var lbSubtitle: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
